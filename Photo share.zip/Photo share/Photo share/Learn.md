# Djangxel

Djangxel is a photo sharing platform built using the Django web framework. It is a college mini project designed to help students learn the basics of web development using Python and Django.
